<template>
    <div class="footer">
      <p>&copy; 2024 Web Technology SECJ3483. All rights reserved.</p>
    </div>
  </template>
  
  <script>
  export default {
    name: 'AppFooter'
  }
  </script>
  
  <style scoped>
  .footer {
    width: 100%;
    background-color: black;
    color: #fff;
    padding: 20px 0;
    text-align: center;
  }
  </style>